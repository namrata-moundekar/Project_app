from django.shortcuts import render, redirect,HttpResponse
from movie_app.forms import MovieForm
from movie_app.models import Movie
from django.urls import reverse_lazy
from django.contrib import messages
from django.views.generic.base import RedirectView, TemplateView
from django.views import View
from datetime import datetime
import pandas as pd
from django.db import connection as conn
from .resources import MovieResource
from tablib import Dataset
from django.db.models import Q
# import xlwt
# Create your views here.
# {% if p.poster_image  or p.poster_image.url %}

def movie_upload(request):
    if request.method == 'POST':
        MOVIE_resource = MovieResource()
        dataset = Dataset()
        new_MOVIE = request.FILES['myfile']

        imported_data = dataset.load(new_MOVIE.read())
        result = MOVIE_resource.import_data(dataset, dry_run=True)
        

        if not result.has_errors():
            MOVIE_resource.import_data(dataset, dry_run=False)
        messages.success(request,('File Uploaded Successfully into  Database....!'))

    return render(request, 'Dashboard/upload_movie.html')


def filter_movie(request):
    if request.method=='POST': 
        m_name = request.POST.get('m_name')
        actor = request.POST.get('actor')
        r_date = request.POST.get('r_date')
        m_type = request.POST.get('m_type')
        
        if (m_name and actor and r_date and m_type):
            # queries=Movie.objects.raw(f"""select id,name,actors,genres,release_date from movie_info  WHERE name LIKE '%{m_name}%' and actors LIKE '%{actor}%' and genres LIKE '%{m_type}%' """)
            # queries=Movie.objects.filter(Q(name__icontains=m_name) & Q(actors__icontains=actor) & Q(genres__icontains=m_type) & Q(release_date__icontains=r_date))
            queries=Movie.objects.filter(name__icontains=m_name,actors__icontains=actor,genres__icontains=m_type,release_date__icontains=r_date)
            return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )
        if (m_name):
            queries=Movie.objects.filter(name__icontains=m_name)
            return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )
        if (actor):
            queries=Movie.objects.filter(actors__icontains=actor)
            return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )
        if (r_date ):
            queries=Movie.objects.filter(release_date__icontains=r_date)
            return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )
        if (m_type):
            queries=Movie.objects.filter(genres__icontains=m_type)
            return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )
        else:
            queries=Movie.objects.all()
            return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )
        
        
    else:
        queries=Movie.objects.all()
        return render(request, 'Dashboard/filter_movie.html',{'movie_data':queries} )



def add_show_movie(request):
    if request.method=='POST':
        form=MovieForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            form=MovieForm()
        my_dict={'form':form}
    else:
        form=MovieForm()
    movie_data=Movie.objects.all()
   
    
    my_dict={'form':form,'movie_data':movie_data}
    return render(request=request,template_name='Dashboard/addshow_movie.html',context=my_dict)
    
 	
class MoviedetailsUpdateView(View):
	def get(self, request, id):
		movie_data = Movie.objects.get(id = id)
		form = MovieForm(instance=movie_data)
		return render(request, 'Dashboard/updatemovie.html', {'form':form})

	def post(self, request, id):
		movie_data = Movie.objects.get(id = id)
		form = MovieForm(request.POST,request.FILES,instance=movie_data)
		if form.is_valid():
			form.save()
		return redirect('/dash/')




# This Function will Delete Movie
def delete_movie_data(request, id):
 	movie_data = Movie.objects.get(id = id)
 	movie_data.delete()
 	return redirect('/dash/')







# def movie_upload(request):
#     if request.method == 'POST':
#         MOVIE_resource = MovieResource()
#         dataset = Dataset()
#         # iam=IAM_IDForm(request.FILES)
#         # if iam.is_valid():
#         # if new_IAM_ID in request.FILES:
#         #     new_IAM_ID = request.FILES['myfile']
#         # else:
#         #     myfile = False

#         new_MOVIE = request.FILES['myfile']
#         # print(new_IAM_ID)
#         # new_IAM_ID.save()
#         # if form.is_valid():
#         #     form.save()
#         imported_data = dataset.load(new_MOVIE.read(), format='xlsx')
#         # print(imported_data)
#         try:
#             for data in imported_data:
#                 # print(data)
#                 # print(data[platform])
#                 value = Movie(
#                     data[0],
#                     data[1],
#                     data[2],
#                     data[3],
#                     data[4],
#                     data[5],
                    

#                 )
               
#                 value.save()
#                 print(data[1])
#                 print(data[4])
#             messages.success(request,('File Uploaded Successfully into  Database....!'))
#         except NameError:
#                 print("not defined")

#             # result = person_resource.import_data(dataset, dry_run=True)  # Test the data import

#         # if not result.has_errors():
#         #    person_resource.import_data(dataset, dry_run=False)  # Actually import now

#     return render(request, 'Dashboard/upload_movie.html')
    



# def movie_upload(request):
#     if request.method == 'POST':
#         # Moviedetails_resource = MoviedetailsResource()
#         # dataset = Dataset()
        

#         new_Moviedetails = request.FILES['myfile']
#         readExcel= pd.read_excel(new_Moviedetails)
#         readExcel["release_date"] = pd.datetime.strftime(readExcel.iloc[2], "%Y-%m-%d")
#         # readExcel["End_date"] = pd.datetime.strftime(readExcel.iloc[27], "%Y-%m-%d")
#         # readExcel["start_date"] = pd.to_datetime(readExcel["start_date"]).dt.strftime("%Y-%m-%d")
#         # readExcel["End_date"] = pd.to_datetime(readExcel["End_date"]).dt.strftime("%Y-%m-%d")
#         readExcel= readExcel.set_index('id')
#         # readExcel=readExcel(int('start_date')).format="%d-%m-%y"
#         # readExcel=readExcel(int('End_date')).format="%d-%m-%y"
#         try:
#             # conn = mysql.connect("movieinfodb.mysql")

#             cursor = conn.cursor()
#             readExcel.to_sql('movie_info', conn, if_exists='append')
            
#             conn.commit()
#             cursor.close()
           
#             messages.success(request,('File Uploaded Successfully into Database....!'))
#         except NameError:
#                 print("not defined")

            

#     return render(request, 'Dashboard/upload_movie.html')



