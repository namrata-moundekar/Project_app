from django.contrib import admin
from movie_app.models import Movie

# Register your models here.
admin.site.register(Movie)