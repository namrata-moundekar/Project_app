from django.core import validators
from django import forms
from movie_app.models import Movie



class DateInput(forms.DateInput):
    input_type= 'date'

Demo_choices=[('p','p')]

class MovieForm(forms.ModelForm):
    
    
	class Meta:
		model = Movie
		fields = ['name', 'release_date', 'actors','poster_image','genres']
		widgets = {
		'name': forms.TextInput(attrs = {'class':'form-control'}),
		'release_date': DateInput(attrs = {'class':'form-control'}),
        'actors': forms.Textarea(attrs = {'class':'form-control','rows':'3','cols':'40'}),
        'poster_image': forms.FileInput(attrs = {'class':'form-control'}),
        'genres': forms.CheckboxSelectMultiple(),
        
        
		}
        

	def __init__(self, *args, **kwargs):
		super(MovieForm, self).__init__(*args, **kwargs)
		
        


