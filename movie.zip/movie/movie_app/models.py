from django.db import models
from multiselectfield import MultiSelectField
from django.core.validators import MaxValueValidator, MinValueValidator

# Create your models here.
GENRES_CHOICES=(
        ('Action','Action'),
        ('Drama','Drama'),
        ('Comedy','Comedy'),
        ('Romance','Romance'),
        ('Horror','Horror'),
        ('Adventure','Adventure'),
    )

class Movie(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    release_date = models.DateField(null=True,blank=True)
    actors = models.CharField(max_length=1000,null=True,blank=True)
    poster_image = models.ImageField(upload_to='images/',max_length=1000,null=True,blank=True) 
    genres = MultiSelectField(choices=GENRES_CHOICES,null=True,blank=True,validators = [MinValueValidator(0.0)])
    
    class Meta:
        db_table = 'MOVIE_INFO'